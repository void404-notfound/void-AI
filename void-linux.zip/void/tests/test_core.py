"""Run:  python tests/test_core.py   (no network, no real hardware needed)"""
import json, os, sys, tempfile, threading, time
os.environ["XDG_CONFIG_HOME"] = tempfile.mkdtemp()
os.environ["XDG_DATA_HOME"] = tempfile.mkdtemp()
for k in list(os.environ):
    if k.endswith("_API_KEY"): del os.environ[k]
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from assistant import brain, config, models, offline, perms, tools, memory
from assistant.server import app

ok = fail = 0
def check(name, cond, extra=""):
    global ok, fail
    if cond: ok += 1; print("  PASS", name)
    else: fail += 1; print("  FAIL", name, extra)

# fake hardware: record commands instead of running them
calls = []
tools.run = lambda cmd, timeout=8: (calls.append(cmd) or (0, "ok"))
tools.have = lambda x: x in ("wpctl", "brightnessctl", "nmcli", "playerctl")
tools.spawn = lambda cmd: calls.append(("spawn", cmd))

print("offline routing")
cases = {
  "set the volume to 40": "set_volume", "volume up": "change_volume", "make it quieter": "change_volume",
  "mute": "set_mute", "unmute": "set_mute", "brightness 60": "set_brightness", "dim the screen": "change_brightness",
  "turn off wifi": "wifi_set", "wifi on": "wifi_set", "pause": "media_control", "resume the video": "media_control",
  "play the movie inception": "play_video", "open firefox": "open_app", f"hey {config.APP_NAME.lower()}, open the calculator": "open_app", "unmute my speaker": "set_mute", "turn my screen bigthness to 30": "set_brightness",
  "close chrome": "close_app", "lock the screen": "lock_screen", "shut down": "shutdown", "restart": "restart",
  "battery level": "system_status", "what time is it": "current_time", "remember that I like tea": "remember",
  "please lower the volume": "change_volume", "turn off bluetooth": "bluetooth_set",
}
for text, want in cases.items():
    r = offline.route(text); check(f"'{text}' -> {want}", r and r[0] == want, r)
check("on/off parsed", offline.route("turn off wifi")[1] == {"enabled": False} and offline.route("wifi on")[1] == {"enabled": True})
check("unknown not routed", offline.route("write me a python script") is None)

print("compound commands, typos, rename")
calls.clear(); tools_perm = perms.set_levels({"audio": "allow", "display": "allow"})
r = offline.handle("unmute my speaker and turn my screen bigthness to 30")
check("compound offline command runs both parts", "Unmuted" in r and "30%" in r, r)
perms.set_levels({"media": "allow"})
r = offline.handle("play tom and jerry"); check("'and' inside a title is not split", "tom and jerry" in r, r)
check("app name is Void", config.APP_NAME == "Void" and config.APP_ID == "void")

print("permission gate")
perms.set_levels({g: "off" for g in perms.GROUPS}); check("everything off by default", all(v == "off" for v in perms.levels().values()))
r = tools.execute("set_volume", {"level": 50}); check("off => DENIED", r.startswith("DENIED"), r)
check("denial audited", perms.audit_tail()[0]["outcome"].startswith("blocked"))
perms.set_levels({"audio": "allow"}); calls.clear()
r = tools.execute("set_volume", {"level": 50}); check("allow => runs", "50%" in r and calls, r)
check("schemas exclude off groups", "set_volume" in str(tools.available_schemas()) and "shutdown" not in str(tools.available_schemas()))
perms.set_levels({"power": "allow"}); calls.clear()
def approve_later(ok_):
    for _ in range(50):
        p = perms.pending()
        if p: perms.decide(p[0]["id"], ok_); return
        time.sleep(.05)
threading.Thread(target=approve_later, args=(False,)).start()
r = tools.execute("shutdown", {}); check("dangerous tool asks even on Allow; deny blocks", r.startswith("DENIED") and not any("poweroff" in str(c) for c in calls), r)
threading.Thread(target=approve_later, args=(True,)).start()
r = tools.execute("shutdown", {}); check("approve => runs", any("poweroff" in str(c) for c in calls), r)
perms.set_levels({"audio": "ask"})
threading.Thread(target=approve_later, args=(True,)).start()
tools._vol_get = lambda: (50, False)
threading.Thread(target=approve_later, args=(True,)).start()
r = tools.execute("get_volume", {}); check("'ask' level waits for approval, then runs", r == "Volume is 50%.", r)
threading.Thread(target=approve_later, args=(False,)).start()
r = tools.execute("get_volume", {}); check("'ask' level + deny => blocked", r.startswith("DENIED"), r)

print("safety")
perms.set_levels({"files": "allow", "shell": "allow"})
config.set_key("groq", "SECRET-123")
r = tools.execute("read_file", {"path": str(config.KEYS_FILE)}); check("cannot read API key file", "SECRET" not in r and "Can't read" in r, r)
r = tools.execute("list_files", {"path": "/etc"}); check("cannot browse outside allowed roots", "Can't list" in r, r)
check("dangerous shell blocked", "blocked" in tools.run_command("rm -rf /"))
config.set_key("groq", "")

print("agent loop with fake provider")
config.set_key("groq", "KEY-ABC-123"); perms.set_levels({"audio": "allow"})
models.online = lambda: True
seq = []
def fake_openai(base, key, model, messages, tools_, system):
    seq.append(messages[-1]["role"])
    if messages[-1]["role"] == "user":
        return {"role": "assistant", "content": "", "tool_calls": [{"id": "c1", "type": "function",
                "function": {"name": "set_volume", "arguments": json.dumps({"level": 30})}}]}
    return {"role": "assistant", "content": "Volume is now 30%."}
models._openai = fake_openai
res = brain.handle("make it 30 volume please")
check("online agent calls tool then answers", res["reply"] == "Volume is now 30%." and res["actions"][0]["tool"] == "set_volume" and res["mode"] == "online", res)
check("API key never put in the AI prompt", "KEY-ABC-123" not in brain.system_prompt())
def boom(*a): raise RuntimeError("500")
models._openai = boom; models._fail.clear()
res = brain.handle("volume up"); check("provider failure falls back to offline and still acts", res["mode"] == "offline" and res["reply"].startswith("Volume"), res)
res = brain.handle("explain quantum physics"); check("offline refuses complex stuff politely", "offline" in res["reply"].lower(), res)
config.update(mode="offline"); models._fail.clear()
res = brain.handle("mute"); check("forced offline mode", res["mode"] == "offline"); config.update(mode="auto")

print("anthropic message conversion")
sent = {}
class R:  
    status_code = 200
    def json(self): return {"content": [{"type": "text", "text": "hi"}, {"type": "tool_use", "id": "t1", "name": "get_volume", "input": {}}]}
models.requests.post = lambda url, json=None, headers=None, timeout=None: (sent.update(url=url, body=json, h=headers) or R())
msgs = [{"role": "user", "content": "vol?"}, {"role": "assistant", "content": "", "tool_calls": [{"id": "t0", "type": "function", "function": {"name": "get_volume", "arguments": "{}"}}]},
        {"role": "tool", "tool_call_id": "t0", "content": "Volume is 20%"}]
out = models._anthropic("https://api.anthropic.com/v1", "k", "m", msgs, tools.available_schemas(), "sys")
b = sent["body"]["messages"]
check("anthropic: tool_use + tool_result shaped correctly", b[1]["content"][0]["type"] == "tool_use" and b[2]["content"][0]["type"] == "tool_result" and sent["h"]["x-api-key"] == "k")
check("anthropic: response normalised", out["tool_calls"][0]["function"]["name"] == "get_volume" and out["content"] == "hi")

print("server security")
c = app.test_client(); H = {"X-Requested-With": "fetch"}
check("overview needs login", c.get("/api/overview", headers=H).status_code == 401)
check("setup_done false before setup", c.get("/api/state").json["setup_done"] is False)
check("POST without header rejected", c.post("/api/auth/login", json={"password": "x"}).status_code == 400)
check("bad host rejected (DNS-rebinding guard)", c.get("/api/state", headers={"Host": "evil.com"}).status_code == 400)
check("short password rejected", c.post("/api/auth/setup", json={"password": "123"}, headers=H, environ_base={"REMOTE_ADDR": "127.0.0.1"}).status_code == 400)
check("remote setup refused", c.post("/api/auth/setup", json={"password": "abcdef"}, headers=H, environ_base={"REMOTE_ADDR": "8.8.8.8"}).status_code == 403)
check("local setup ok", c.post("/api/auth/setup", json={"password": "abcdef", "owner": "Tester"}, headers=H, environ_base={"REMOTE_ADDR": "127.0.0.1"}).status_code == 200)
config.update(setup_done=True)
for path in ("/api/command", "/api/processes", "/api/files/read"):
    check(f"old open endpoint {path} gone", c.get(path, headers=H).status_code in (404, 405))
c2 = app.test_client()
check("wrong password rejected", c2.post("/api/auth/login", json={"password": "nope"}, headers=H).status_code == 401)
check("right password logs in", c2.post("/api/auth/login", json={"password": "abcdef"}, headers=H).status_code == 200)
ov = c2.get("/api/overview", headers=H).json
check("overview never leaks keys", "SECRET" not in json.dumps(ov) and ov["providers"][0]["has_key"] is True)
check("static files served", c2.get("/app.js").status_code == 200 and c2.get("/style.css").status_code == 200 and c2.get("/auth.json").status_code == 404)
r = c2.post("/api/permissions", json={"levels": {"audio": "off", "shell": "bogus"}}, headers=H).json
check("permissions endpoint validates", r["levels"]["audio"] == "off" and r["levels"]["shell"] != "bogus")
check("file mode of secrets is 600", oct(os.stat(config.KEYS_FILE).st_mode)[-3:] == "600" and oct(os.stat(config.AUTH_FILE).st_mode)[-3:] == "600")

print(f"\n{ok} passed, {fail} failed"); sys.exit(1 if fail else 0)
