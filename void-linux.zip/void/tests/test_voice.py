"""Run:  python tests/test_voice.py   (no network or audio hardware needed)"""
import http.server, io, json, os, socketserver, struct, subprocess, sys, tempfile, threading, wave, zipfile
os.environ["XDG_CONFIG_HOME"] = tempfile.mkdtemp(); os.environ["XDG_DATA_HOME"] = tempfile.mkdtemp()
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from assistant import config, models, stt, voice, voice_setup, perms
from assistant.server import app

ok = fail = 0
def check(name, cond, extra=""):
    global ok, fail
    if cond: ok += 1; print("  PASS", name)
    else: fail += 1; print("  FAIL", name, extra)

def make_wav(rate=16000, ch=1, secs=1.0):
    b = io.BytesIO()
    with wave.open(b, "wb") as w:
        w.setnchannels(ch); w.setsampwidth(2); w.setframerate(rate); w.writeframes(b"\x01\x02" * int(rate * secs * ch))
    return b.getvalue()

print("wake word")
check("'Hey Void, open firefox'", stt.strip_wake("Hey Void, open firefox") == (True, "open firefox"))
check("'void lock the screen'", stt.strip_wake("void lock the screen") == (True, "lock the screen"))
check("misheard 'avoid' still wakes", stt.strip_wake("avoid mute")[0] is True)
check("normal speech does not wake", stt.strip_wake("what a lovely day") == (False, "what a lovely day"))
check("bare wake word -> empty command", stt.strip_wake("hey void") == (True, ""))

print("audio validation")
check("good wav accepted", stt._check_wav(make_wav()) > 0.9)
for bad, label in ((make_wav(rate=44100), "44.1k rejected"), (make_wav(ch=2), "stereo rejected"), (b"not audio", "garbage rejected")):
    try: stt._check_wav(bad); check(label, False)
    except stt.VoiceError: check(label, True)

print("engine selection & privacy")
stt.local_ready = lambda: True
models.online = lambda: True
config.set_key("groq", "k"); config.update(stt_engine="auto")
check("push-to-talk + auto prefers online, falls back to local", stt.plan(False)[0] == ["online", "local"])
check("HANDS-FREE + auto stays local (room audio never uploaded)", stt.plan(True)[0] == ["local"])
config.update(stt_engine="online"); check("online-only", stt.plan(False)[0] == ["online"])
models.online = lambda: False
try: stt.transcribe(make_wav()); check("online-only offline raises", False)
except stt.VoiceError as e: check("online-only offline raises clear message", "internet" in str(e), str(e))
config.update(stt_engine="auto"); models.online = lambda: True
calls = []
stt.transcribe_online = lambda wav, pid: (_ for _ in ()).throw(stt.VoiceError("groq down"))
stt.transcribe_local = lambda wav: (calls.append("local") or "open firefox")
r = stt.transcribe(make_wav()); check("online fails -> falls back to local automatically", r == {"text": "open firefox", "engine": "local"}, r)
stt.transcribe_local = lambda wav: "thank you"; stt.transcribe_online = lambda w, p: "thank you"
check("Whisper silence hallucination dropped", stt.transcribe(make_wav(secs=1.0))["text"] == "")
check("tiny clips ignored", stt.transcribe(make_wav(secs=0.1))["text"] == "")

print("voice output")
voice.edge_ready = lambda: True; voice.piper_ready = lambda: True; voice.espeak_bin = lambda: "/usr/bin/espeak-ng"
models.online = lambda: True; config.update(tts_engine="auto")
check("online: edge first, then piper, then espeak", voice.engines() == ["edge", "piper", "espeak"])
models.online = lambda: False; check("offline: piper then espeak", voice.engines() == ["piper", "espeak"])
config.update(tts_engine="local"); models.online = lambda: True; check("local-only never uses edge", "edge" not in voice.engines())
config.update(tts_engine="auto")
voice._piper = lambda t: (_ for _ in ()).throw(voice.VoiceError("piper broke"))
voice._espeak = lambda t: (b"RIFFxxxx", "audio/wav")
models.online = lambda: False
data, mime, eng = voice.synthesize("Hello **there** https://x.com"); check("engine failure falls through to espeak", eng == "espeak")
check("markdown/URLs stripped before speaking", voice.clean("**Hi** `x` https://a.b/c") == "Hi x link")
check("default voice is deep male + lowered pitch + slower", config.get("edge_voice") == "en-US-ChristopherNeural" and config.get("edge_pitch").startswith("-") and config.get("edge_rate").startswith("-"))
voice.espeak_bin = lambda: None; voice.piper_ready = lambda: False
try: voice.synthesize("hi"); check("no engine -> helpful error", False)
except voice.VoiceError as e: check("no engine -> helpful error", "Install" in str(e), str(e))

print("model download (against a local server)")
tmp = tempfile.mkdtemp()
with zipfile.ZipFile(os.path.join(tmp, "vosk.zip"), "w") as z: z.writestr(f"{stt.MODEL_NAME}/am/final.mdl", "x"); z.writestr(f"{stt.MODEL_NAME}/conf/mfcc.conf", "x")
for ext in (".onnx", ".onnx.json"): open(os.path.join(tmp, "en_US-ryan-medium" + ext), "wb").write(b"0" * 5000)
class Q(http.server.SimpleHTTPRequestHandler):
    def __init__(s, *a, **k): super().__init__(*a, directory=tmp, **k)
    def log_message(s, *a): pass
srv = socketserver.TCPServer(("127.0.0.1", 0), Q); threading.Thread(target=srv.serve_forever, daemon=True).start()
port = srv.server_address[1]
voice_setup.VOSK_URL = f"http://127.0.0.1:{port}/vosk.zip"; voice_setup.PIPER_BASE = f"http://127.0.0.1:{port}/" + "{voice}"
voice_setup.install_stt(); check("speech model downloaded + unpacked", voice_setup.PROGRESS["stt"]["state"] == "done" and (stt.MODEL_DIR / "am" / "final.mdl").exists(), voice_setup.PROGRESS["stt"])
voice_setup.install_tts(); check("deep voice downloaded", voice_setup.PROGRESS["tts"]["state"] == "done" and (voice.PIPER_DIR / "en_US-ryan-medium.onnx").exists(), voice_setup.PROGRESS["tts"])
voice_setup.VOSK_URL = f"http://127.0.0.1:{port}/missing.zip"; voice_setup.install_stt()
check("failed download reports an error, no crash", voice_setup.PROGRESS["stt"]["state"] == "error")
srv.shutdown()

print("endpoints")
H = {"X-Requested-With": "fetch"}
c = app.test_client()
c.post("/api/auth/setup", json={"password": "abcdef"}, headers=H, environ_base={"REMOTE_ADDR": "127.0.0.1"}); config.update(setup_done=True)
wav = make_wav()
stt.local_ready = lambda: True; stt.transcribe_local = lambda w: "hey void turn the volume down"; stt.transcribe_online = lambda w, p: ""
config.update(mic_enabled=False, stt_engine="local")
r = c.post("/api/voice/transcribe", data=wav, headers={**H, "Content-Type": "audio/wav"}); check("mic OFF => server refuses audio (403)", r.status_code == 403)
config.update(mic_enabled=True)
r = c.post("/api/voice/transcribe", data=wav, headers={**H, "Content-Type": "audio/wav"})
check("mic ON => transcript + wake parsed", r.status_code == 200 and r.json["woke"] and r.json["command"] == "turn the volume down", r.json)
r = c.post("/api/voice/transcribe", data=b"junk", headers={**H, "Content-Type": "audio/wav"}); check("junk audio => clean 503 error", r.status_code == 503 and "error" in r.json)
voice.synthesize = lambda t: (b"RIFF", "audio/wav", "espeak")
r = c.post("/api/voice/speak", json={"text": "hi"}, headers=H); check("speak returns audio", r.status_code == 200 and r.mimetype == "audio/wav" and r.headers["X-Voice-Engine"] == "espeak")
c2 = app.test_client()
check("voice endpoints need login", all(c2.post(p, data=b"x", headers=H).status_code == 401 for p in ("/api/voice/transcribe", "/api/voice/speak", "/api/voice/install")))
check("CSP allows only own scripts + blob audio; mic limited to self", "script-src 'self'" in r.headers["Content-Security-Policy"] and "media-src 'self' blob:" in r.headers["Content-Security-Policy"] and "microphone=(self)" in r.headers["Permissions-Policy"])
r = c.get("/api/voice/status"); check("status reports readiness", r.status_code == 200 and "stt_ready" in r.json and "Christopher" in json.dumps(r.json["voices"]))
r = c.post("/api/settings", json={"edge_voice": "evil-voice", "listen_mode": "weird", "stt_engine": "local"}, headers=H); check("settings reject unknown values", config.get("edge_voice") == "en-US-ChristopherNeural" and config.get("listen_mode") == "push")
check("browser JS files served", all(c.get(f"/{f}").status_code == 200 for f in ("voice.js", "blackhole.js", "app.js", "style.css")))

print("browser WAV encoder (node)")
js = r'''
const V = require(process.argv[2]); const {encodeWav, resample} = V._test;
const rate = 48000, f = new Float32Array(rate); for (let i = 0; i < rate; i++) f[i] = 0.5 * Math.sin(2*Math.PI*440*i/rate);
(async () => { const blob = encodeWav([f.slice(0, 24000), f.slice(24000)], rate); const b = Buffer.from(await blob.arrayBuffer());
console.log(JSON.stringify({riff: b.toString("ascii",0,4), wave: b.toString("ascii",8,12), ch: b.readUInt16LE(22), rate: b.readUInt32LE(24), bits: b.readUInt16LE(34), bytes: b.length - 44, peak: Math.max(...Array.from({length: 200}, (_, i) => b.readInt16LE(44 + i*2)))})); })();'''
open(os.path.join(tmp, "t.js"), "w").write(js)
o = subprocess.run(["node", os.path.join(tmp, "t.js"), os.path.join(ROOT, "assistant/ui/voice.js")], capture_output=True, text=True)
try: j = json.loads(o.stdout)
except ValueError: j = {}; print(o.stderr[-300:])
check("WAV header: RIFF/WAVE, mono, 16 kHz, 16-bit", j.get("riff") == "RIFF" and j.get("wave") == "WAVE" and j.get("ch") == 1 and j.get("rate") == 16000 and j.get("bits") == 16, j)
check("48 kHz -> 16 kHz resample gives 1 s = 32000 bytes", j.get("bytes") == 32000, j)
check("audio level preserved (not silent / not clipped)", 8000 < j.get("peak", 0) < 17000, j)

print(f"\n{ok} passed, {fail} failed"); sys.exit(1 if fail else 0)
