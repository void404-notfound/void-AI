"""Downloads the offline voice models (Vosk speech recognition + Piper voice, ~100 MB total).
Run by the installer, or from Settings → Voice, or:  python -m assistant.voice_setup"""
import os, shutil, threading, zipfile
import requests
from . import config, stt, voice

VOSK_URL = f"https://alphacephei.com/vosk/models/{stt.MODEL_NAME}.zip"
PIPER_BASE = "https://huggingface.co/rhasspy/piper-voices/resolve/main/{lang}/{locale}/{name}/{quality}/{voice}"
PROGRESS = {k: {"state": "idle", "pct": 0, "msg": ""} for k in ("stt", "tts")}
_threads = {}


def _set(key, **kw):
    PROGRESS[key].update(kw)


def _download(url, dest, key, lo, hi):
    with requests.get(url, stream=True, timeout=30) as r:
        r.raise_for_status()
        total, got = int(r.headers.get("content-length", 0)), 0
        tmp = str(dest) + ".part"
        with open(tmp, "wb") as f:
            for chunk in r.iter_content(1 << 16):
                f.write(chunk)
                got += len(chunk)
                if total:
                    _set(key, pct=int(lo + (hi - lo) * got / total))
        os.replace(tmp, dest)


def install_stt():
    _set("stt", state="downloading", pct=1, msg="Downloading speech model…")
    try:
        base = stt.MODEL_DIR.parent
        base.mkdir(parents=True, exist_ok=True)
        zpath = base / "vosk.zip"
        _download(VOSK_URL, zpath, "stt", 1, 90)
        _set("stt", msg="Unpacking…", pct=92)
        with zipfile.ZipFile(zpath) as z:
            z.extractall(base)
        zpath.unlink()
        if not (stt.MODEL_DIR / "am").exists():
            raise RuntimeError("model folder looks wrong after unpacking")
        _set("stt", state="done", pct=100, msg="Ready")
    except Exception as e:
        _set("stt", state="error", msg=f"{type(e).__name__}: {str(e)[:120]}")


def install_tts():
    _set("tts", state="downloading", pct=1, msg="Downloading voice…")
    try:
        name = config.get("piper_voice")                   # e.g. en_US-ryan-medium
        locale, speaker, quality = name.split("-")
        url = PIPER_BASE.format(lang=locale.split("_")[0], locale=locale, name=speaker, quality=quality, voice=name)
        voice.PIPER_DIR.mkdir(parents=True, exist_ok=True)
        _download(url + ".onnx.json", voice.PIPER_DIR / f"{name}.onnx.json", "tts", 1, 5)
        _download(url + ".onnx", voice.PIPER_DIR / f"{name}.onnx", "tts", 5, 100)
        _set("tts", state="done", pct=100, msg="Ready")
    except Exception as e:
        _set("tts", state="error", msg=f"{type(e).__name__}: {str(e)[:120]}")


def start(what):
    fn = {"stt": install_stt, "tts": install_tts}[what]
    t = _threads.get(what)
    if t and t.is_alive():
        return False
    _threads[what] = threading.Thread(target=fn, daemon=True)
    _threads[what].start()
    return True


def status():
    return {"stt_ready": stt.local_ready(), "tts_ready": voice.piper_ready(),
            "vosk_pkg": stt.importlib.util.find_spec("vosk") is not None,
            "piper_pkg": stt.importlib.util.find_spec("piper") is not None,
            "edge_pkg": voice.edge_ready(), "espeak": bool(voice.espeak_bin()), "progress": PROGRESS}


if __name__ == "__main__":
    for key, fn in (("stt", install_stt), ("tts", install_tts)):
        if (key == "stt" and stt.local_ready()) or (key == "tts" and voice.piper_ready()):
            print(f"{key}: already installed"); continue
        print(f"{key}: downloading…"); fn(); print(f"{key}: {PROGRESS[key]['state']} {PROGRESS[key]['msg']}")
