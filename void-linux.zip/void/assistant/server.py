"""Local web server + API for the UI. Secure by default:
 - listens on 127.0.0.1 only (LAN access is an explicit setting)
 - every /api call needs a logged-in session (password set at first run)
 - cookies are SameSite=Strict, POSTs need a custom header, Host header is checked
 - no CORS, no public tunnels
"""
import hashlib, hmac, os, secrets, time
from pathlib import Path
from flask import Flask, Response, jsonify, request, send_from_directory, session

from . import brain, config, memory, models, perms, scheduler, stt, tools, voice, voice_setup

UI_DIR = Path(__file__).parent / "ui"
app = Flask(__name__)
app.secret_key = config.session_secret()
app.config.update(MAX_CONTENT_LENGTH=12 * 1024 * 1024, SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Strict",
                  PERMANENT_SESSION_LIFETIME=60 * 60 * 24 * 14)
_attempts = {}


# ── password ─────────────────────────────────────────────────
def _hash(pw, salt):
    return hashlib.scrypt(pw.encode(), salt=salt, n=2 ** 14, r=8, p=1).hex()


def _set_password(pw):
    salt = secrets.token_bytes(16)
    config.write_json(config.AUTH_FILE, {"salt": salt.hex(), "hash": _hash(pw, salt)}, private=True)


def _check_password(pw):
    a = config.read_json(config.AUTH_FILE, None)
    return bool(a) and hmac.compare_digest(_hash(pw, bytes.fromhex(a["salt"])), a["hash"])


# ── guards ───────────────────────────────────────────────────
@app.before_request
def guard():
    if not config.get("allow_lan"):
        host = request.host.rsplit(":", 1)[0].strip("[]")
        if host not in ("127.0.0.1", "localhost", "::1"):
            return jsonify(error="bad host"), 400
    if request.path.startswith("/api/"):
        if request.method in ("POST", "DELETE") and request.headers.get("X-Requested-With") != "fetch":
            return jsonify(error="missing header"), 400
        if not request.path.startswith(("/api/state", "/api/auth/")) and not session.get("ok"):
            return jsonify(error="login required"), 401


@app.after_request
def headers(r):
    r.headers["Cache-Control"] = "no-store"
    r.headers["X-Content-Type-Options"] = "nosniff"
    r.headers["Content-Security-Policy"] = "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; script-src 'self'; media-src 'self' blob:"
    r.headers["Permissions-Policy"] = "microphone=(self), camera=()"
    return r


@app.route("/")
def index():
    return send_from_directory(UI_DIR, "index.html")


@app.route("/<name>")
def ui_file(name):
    if name not in ("app.js", "style.css", "voice.js", "blackhole.js"):
        return jsonify(error="not found"), 404
    return send_from_directory(UI_DIR, name)


# ── auth ─────────────────────────────────────────────────────
@app.route("/api/state")
def state():
    return jsonify(setup_done=config.get("setup_done"), authed=bool(session.get("ok")), name=config.APP_NAME)


def _throttled():
    ip, now = request.remote_addr, time.time()
    _attempts[ip] = [t for t in _attempts.get(ip, []) if now - t < 60]
    return len(_attempts[ip]) >= 6


@app.route("/api/auth/setup", methods=["POST"])
def auth_setup():
    if config.get("setup_done") or request.remote_addr not in ("127.0.0.1", "::1"):
        return jsonify(error="already set up"), 403
    d = request.get_json(silent=True) or {}
    if len(d.get("password", "")) < 6:
        return jsonify(error="Password must be at least 6 characters."), 400
    _set_password(d["password"])
    config.update(owner=str(d.get("owner", ""))[:40], city=str(d.get("city", ""))[:60])
    session.permanent, session["ok"] = True, True
    return jsonify(ok=True)


@app.route("/api/auth/login", methods=["POST"])
def auth_login():
    if _throttled():
        return jsonify(error="Too many attempts. Wait a minute."), 429
    _attempts.setdefault(request.remote_addr, []).append(time.time())
    if _check_password((request.get_json(silent=True) or {}).get("password", "")):
        session.permanent, session["ok"] = True, True
        return jsonify(ok=True)
    return jsonify(error="Wrong password."), 401


@app.route("/api/auth/logout", methods=["POST"])
def auth_logout():
    session.clear()
    return jsonify(ok=True)


# ── data ─────────────────────────────────────────────────────
@app.route("/api/overview")
def overview():
    lv = perms.levels()
    keys = {p: config.has_key(p) for p in list(models.PROVIDERS) + list(models.EXTRA_KEYS)}
    s = config.settings()
    return jsonify(
        name=config.APP_NAME, settings={k: s[k] for k in ("owner", "city", "mode", "voice_enabled", "offline_llm",
                                                          "allow_lan", "provider_order", "telegram_contacts", "setup_done", "mic_enabled",
                                                          "listen_mode", "stt_engine", "tts_engine", "edge_voice")},
        online=models.online(), active_providers=models.usable_providers(),
        groups=[{"id": g, "label": v[0], "desc": v[1], "level": lv[g]} for g, v in perms.GROUPS.items()],
        providers=[{"id": p, "label": v["label"], "url": v["url"], "note": v["note"], "has_key": keys[p],
                    "model": models.model_for(p), "error": models.LAST_ERROR.get(p)} for p, v in models.PROVIDERS.items()],
        has_any_key=any(keys[p] for p in models.PROVIDERS),
        extras=[{"id": k, "label": v[0], "url": v[1], "note": v[2], "has_key": keys[k]} for k, v in models.EXTRA_KEYS.items()],
        history=memory.history()[-30:])


@app.route("/api/permissions", methods=["POST"])
def set_permissions():
    return jsonify(levels=perms.set_levels((request.get_json(silent=True) or {}).get("levels", {})))


@app.route("/api/settings", methods=["POST"])
def set_settings():
    d = request.get_json(silent=True) or {}
    upd = {}
    for k in ("owner", "city"):
        if k in d:
            upd[k] = str(d[k])[:60]
    for k in ("voice_enabled", "offline_llm", "allow_lan", "setup_done", "mic_enabled"):
        if k in d:
            upd[k] = bool(d[k])
    for k, allowed in (("listen_mode", ("push", "handsfree")), ("stt_engine", ("auto", "online", "local")),
                       ("tts_engine", ("auto", "online", "local")), ("edge_voice", tuple(voice.EDGE_VOICES))):
        if d.get(k) in allowed:
            upd[k] = d[k]
    if d.get("mode") in ("auto", "online", "offline"):
        upd["mode"] = d["mode"]
    if isinstance(d.get("provider_order"), list):
        upd["provider_order"] = [p for p in d["provider_order"] if p in models.PROVIDERS]
    if isinstance(d.get("telegram_contacts"), dict):
        upd["telegram_contacts"] = {str(k).lower()[:30]: str(v)[:30] for k, v in d["telegram_contacts"].items()}
    if isinstance(d.get("models"), dict):
        cur = config.get("models")
        cur.update({k: str(v)[:80] for k, v in d["models"].items() if k in models.PROVIDERS})
        upd["models"] = cur
    config.update(**upd)
    return jsonify(ok=True)


@app.route("/api/keys", methods=["POST"])
def set_key():
    d = request.get_json(silent=True) or {}
    name = d.get("provider")
    if name in models.PROVIDERS or name in models.EXTRA_KEYS:
        config.set_key(name, str(d.get("key", ""))[:300])
        models._fail.pop(name, None)
        models.LAST_ERROR.pop(name, None)
        return jsonify(ok=True)
    return jsonify(error="unknown provider"), 400


@app.route("/api/keys/test", methods=["POST"])
def key_test():
    pid = (request.get_json(silent=True) or {}).get("provider")
    if pid not in models.PROVIDERS:
        return jsonify(error="unknown provider"), 400
    ok, msg = models.test(pid)
    return jsonify(ok=ok, message=msg)


# ── voice ────────────────────────────────────────────────────
@app.route("/api/voice/status")
def voice_status():
    order, online = stt.plan(False)
    return jsonify(**voice_setup.status(), mic_enabled=config.get("mic_enabled"), voices=voice.EDGE_VOICES,
                   stt_online_provider=online, stt_order=order, tts_order=voice.engines())


@app.route("/api/voice/transcribe", methods=["POST"])
def voice_transcribe():
    if not config.get("mic_enabled"):
        return jsonify(error="The microphone is turned off. Enable it in Settings → Voice."), 403
    try:
        r = stt.transcribe(request.get_data(), continuous=request.args.get("continuous") == "1")
    except stt.VoiceError as e:
        return jsonify(error=str(e)), 503
    woke, command = stt.strip_wake(r["text"]) if r["text"] else (False, "")
    return jsonify(text=r["text"], engine=r["engine"], woke=woke, command=command)


@app.route("/api/voice/speak", methods=["POST"])
def voice_speak():
    try:
        data, mime, eng = voice.synthesize((request.get_json(silent=True) or {}).get("text", ""))
    except stt.VoiceError as e:
        return jsonify(error=str(e)), 503
    return Response(data, mimetype=mime, headers={"X-Voice-Engine": eng})


@app.route("/api/voice/install", methods=["POST"])
def voice_install():
    what = (request.get_json(silent=True) or {}).get("what")
    if what not in ("stt", "tts"):
        return jsonify(error="unknown"), 400
    return jsonify(started=voice_setup.start(what))


@app.route("/api/chat", methods=["POST"])
def chat():
    return jsonify(brain.handle((request.get_json(silent=True) or {}).get("text", "")))


@app.route("/api/chat/clear", methods=["POST"])
def chat_clear():
    memory.clear()
    return jsonify(ok=True)


@app.route("/api/approvals")
def approvals():
    return jsonify(items=perms.pending())


@app.route("/api/approvals/<aid>", methods=["POST"])
def approval_decide(aid):
    return jsonify(ok=perms.decide(aid, (request.get_json(silent=True) or {}).get("approve")))


@app.route("/api/audit")
def audit():
    return jsonify(items=perms.audit_tail())


@app.route("/api/schedules")
def schedules():
    return jsonify(items=scheduler.load())


@app.route("/api/schedules/<sid>", methods=["DELETE"])
def schedule_delete(sid):
    return jsonify(ok=scheduler.remove(sid))
