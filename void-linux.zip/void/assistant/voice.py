"""Text-to-speech with a deep, cold male voice.

Online : Microsoft Edge neural voice (edge-tts), default 'Christopher', pitched down and slowed.
Local  : Piper neural voice (en_US-ryan-medium) - offline, natural, light on CPU.
Last   : espeak-ng, a low robotic male voice, so there is always *some* voice.
"""
import asyncio, importlib.util, os, re, shutil, subprocess, sys, tempfile, threading
from . import config, models, tools
from .stt import VoiceError

PIPER_DIR = config.DATA_DIR / "models" / "piper"
EDGE_VOICES = {"en-US-ChristopherNeural": "Christopher: deep, calm (default)",
               "en-US-GuyNeural": "Guy: strong, steady",
               "en-GB-RyanNeural": "Ryan: British, cool",
               "en-US-EricNeural": "Eric: clear, neutral"}
_lock = threading.Lock()


def clean(text):
    text = re.sub(r"https?://\S+", "link", text)
    text = re.sub(r"[*_`#>|~]", "", text)
    return re.sub(r"\s+", " ", text).strip()[:700]


def edge_ready():
    return importlib.util.find_spec("edge_tts") is not None


def piper_ready():
    return importlib.util.find_spec("piper") is not None and (PIPER_DIR / f"{config.get('piper_voice')}.onnx").exists()


def espeak_bin():
    return shutil.which("espeak-ng") or shutil.which("espeak")


def _edge(text):
    import edge_tts
    out = tempfile.mktemp(suffix=".mp3")
    try:
        async def go():
            await asyncio.wait_for(edge_tts.Communicate(text, config.get("edge_voice"), rate=config.get("edge_rate"),
                                                        pitch=config.get("edge_pitch")).save(out), 20)
        asyncio.run(go())
        with open(out, "rb") as f:
            return f.read(), "audio/mpeg"
    except Exception as e:
        raise VoiceError(f"Online voice failed ({type(e).__name__}: {str(e)[:80]}).")
    finally:
        if os.path.exists(out):
            os.remove(out)


def _piper(text):
    out = tempfile.mktemp(suffix=".wav")
    try:
        p = subprocess.run([sys.executable, "-m", "piper", "-m", str(PIPER_DIR / f"{config.get('piper_voice')}.onnx"), "-f", out],
                           input=text.encode(), capture_output=True, timeout=40)
        if p.returncode != 0 or not os.path.exists(out):
            raise VoiceError("Piper failed: " + p.stderr.decode(errors="replace")[-160:])
        with open(out, "rb") as f:
            return f.read(), "audio/wav"
    except subprocess.TimeoutExpired:
        raise VoiceError("Piper timed out.")
    finally:
        if os.path.exists(out):
            os.remove(out)


def _espeak(text):
    p = subprocess.run([espeak_bin(), "-v", "en-us+m3", "-p", "22", "-s", "140", "--stdout", text],
                       capture_output=True, timeout=30)
    if p.returncode != 0 or not p.stdout:
        raise VoiceError("espeak failed.")
    return p.stdout, "audio/wav"


def engines():
    """Ordered list of usable engines for the current settings."""
    pref, order = config.get("tts_engine"), []
    if pref in ("auto", "online") and edge_ready() and models.online():
        order.append("edge")
    if pref in ("auto", "local"):
        if piper_ready():
            order.append("piper")
        if espeak_bin():
            order.append("espeak")
    return order


def synthesize(text):
    """Returns (audio_bytes, mime_type, engine). Raises VoiceError with a helpful reason."""
    text = clean(text)
    if not text:
        raise VoiceError("Nothing to say.")
    order = engines()
    if not order:
        raise VoiceError("No voice engine available. Install the offline voice (Settings → Voice) or connect to the internet.")
    errors = []
    for eng in order:
        try:
            data, mime = {"edge": _edge, "piper": _piper, "espeak": _espeak}[eng](text)
            return data, mime, eng
        except (VoiceError, OSError, subprocess.SubprocessError) as e:
            errors.append(str(e))
    raise VoiceError(" ".join(errors))


def speak_local(text):
    """Speak through this computer's speakers (used for scheduled tasks when the browser isn't involved)."""
    def job():
        with _lock:
            try:
                data, mime, _ = synthesize(text)
            except VoiceError:
                return
            f = tempfile.mktemp(suffix=".mp3" if "mpeg" in mime else ".wav")
            with open(f, "wb") as fh:
                fh.write(data)
            for cmd in (["mpv", "--no-video", "--really-quiet", f], ["paplay", f], ["aplay", "-q", f], ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", f]):
                if tools.have(cmd[0]) and tools.run(cmd, 90)[0] == 0:
                    break
            os.path.exists(f) and os.remove(f)
    threading.Thread(target=job, daemon=True).start()
