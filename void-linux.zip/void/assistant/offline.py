"""Offline brain: simple, instant, no AI model needed.

Understands a fixed set of everyday commands with pattern matching and runs them
through the same permission gate as the online AI. Unknown requests get an honest
"I can't do that offline" (or a short reply from a tiny local model if enabled).
"""
import difflib, re
from . import config, models, tools

NUM = r"(\d{1,3})"


def _rules():
    return [
        (r"^(?:un)?mute\b(?: (?:my |the )?(?:sound|volume|audio|speakers?|laptop|computer))?$", lambda m, t: ("set_mute", {"muted": not t.startswith("un")})),
        (rf"(?:volume|sound)\s*(?:to|at|=)?\s*{NUM}\s*%?|{NUM}\s*%?\s*volume", lambda m, t: ("set_volume", {"level": int(m.group(1) or m.group(2))})),
        (r"(?:volume|sound)\s*(?:up|higher)|louder|(?:raise|increase|turn up)\b.*(?:volume|sound)|turn it up", lambda m, t: ("change_volume", {"amount": 10})),
        (r"(?:volume|sound)\s*(?:down|lower)|quieter|softer|(?:lower|decrease|reduce|turn down)\b.*(?:volume|sound)|turn it down", lambda m, t: ("change_volume", {"amount": -10})),
        (rf"bright\w*.*?{NUM}|{NUM}\s*%?\s*bright", lambda m, t: ("set_brightness", {"level": int(m.group(1) or m.group(2))})),
        (r"bright|dim|\bup\b.*screen", lambda m, t: ("change_brightness", {"amount": -15 if re.search(r"dim|down|lower|decrease|reduce|less", t) else 15})),
        (r"(?:(?:turn|switch)\s+)?(on|off)\s+(?:the\s+)?wi-?fi|wi-?fi\s+(on|off)|(enable|disable)\s+wi-?fi", lambda m, t: ("wifi_set", {"enabled": bool(re.search(r"\bon\b|enable", t))})),
        (r"(?:(?:turn|switch)\s+)?(on|off)\s+(?:the\s+)?bluetooth|bluetooth\s+(on|off)|(enable|disable)\s+bluetooth", lambda m, t: ("bluetooth_set", {"enabled": bool(re.search(r"\bon\b|enable", t))})),
        (r"which wi-?fi|wi-?fi status|am i connected", lambda m, t: ("wifi_status", {})),
        (r"^(pause|resume|play|stop|next|previous|skip|continue)(?: (?:the )?(?:video|movie|music|song|track|playback|it))?$",
         lambda m, t: ("media_control", {"action": {"pause": "pause", "resume": "play", "play": "play", "continue": "play", "stop": "stop", "next": "next", "skip": "next", "previous": "previous"}[m.group(1)]})),
        (r"^(?:forward|skip ahead|fast forward)\s*(\d+)?", lambda m, t: ("media_seek", {"seconds": int(m.group(1) or 10)})),
        (r"^(?:rewind|go back)\s*(\d+)?", lambda m, t: ("media_seek", {"seconds": -int(m.group(1) or 10)})),
        (r"^play (?:the )?(?:video|movie|film)?\s*(.+)$", lambda m, t: ("play_video", {"query": m.group(1)})),
        (r"^(?:open|launch|start|run)\s+(?:the\s+)?(.+)$", lambda m, t: ("open_app", {"name": m.group(1)})),
        (r"^(?:close|quit|exit|kill)\s+(?:the\s+)?(.+)$", lambda m, t: ("close_app", {"name": m.group(1)})),
        (r"^lock(?: (?:the )?(?:screen|computer|pc|laptop))?$", lambda m, t: ("lock_screen", {})),
        (r"^(?:sleep|suspend|go to sleep)$", lambda m, t: ("suspend", {})),
        (r"^(?:shut ?down|power off|turn off (?:the )?(?:computer|laptop|pc))$", lambda m, t: ("shutdown", {})),
        (r"^(?:restart|reboot)(?: (?:the )?(?:computer|laptop|pc))?$", lambda m, t: ("restart", {})),
        (r"battery|cpu|\bram\b|memory usage|disk|system (?:status|info)|how.s the (?:system|computer|pc)", lambda m, t: ("system_status", {})),
        (r"what.?s the time|what time|current time|what.?s the date|what day|today.?s date", lambda m, t: ("current_time", {})),
        (r"^(?:remember|note)(?: that)?\s+(.+)$", lambda m, t: ("remember" if t.startswith("remember") else "add_note", {"fact" if t.startswith("remember") else "text": m.group(1)})),
        (r"^(?:show|read) (?:my )?notes$", lambda m, t: ("read_notes", {})),
    ]


VOCAB = ["volume", "brightness", "bluetooth", "unmute", "battery", "speaker", "screen", "restart", "shutdown"]


def _fix_typos(t):
    out = []
    for w in t.split():
        if len(w) >= 5 and w not in VOCAB:
            m = difflib.get_close_matches(w, VOCAB, n=1, cutoff=0.8)
            w = m[0] if m else w
        out.append(w)
    return " ".join(out)


def route(text):
    t = _fix_typos(text.lower().strip().rstrip(".!?"))
    t = re.sub(rf"^(?:hey|ok|okay|yo)?\s*{re.escape(config.APP_NAME.lower())}[,:]?\s+", "", t)
    t = re.sub(r"^(?:please|pls|can you|could you|will you)\s+", "", t)
    t = re.sub(r"\s+(?:please|pls|for me)$", "", t)
    for pat, build in _rules():
        m = re.search(pat, t)
        if m:
            return build(m, t)
    return None


CAN_DO = ("volume, brightness, Wi-Fi/Bluetooth, play/pause videos, open or close apps, lock/sleep/shutdown, "
          "battery and system status, the time, and notes")


def handle(text, source="user"):
    # "unmute and set brightness to 30": run each part if EVERY part is understood
    parts = [p for p in re.split(r"\s*(?:,|;|\band then\b|\bthen\b|\band\b)\s*", text) if p.strip()]
    if len(parts) > 1:
        routed = [route(p) for p in parts]
        if all(routed):
            return " ".join(tools.execute(n, a, source) for n, a in routed)
    r = route(text)
    if r:
        return tools.execute(r[0], r[1], source)
    if config.get("offline_llm"):
        reply = models.ollama_chat(text, f"You are {config.APP_NAME}, a brief, friendly assistant. Answer in one or two short sentences.")
        if reply:
            return reply
    return f"I'm offline right now, so I can only do simple things: {CAN_DO}. Reconnect and I can do a lot more."
