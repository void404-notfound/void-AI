"""Run with:  python -m assistant   [--port N] [--no-browser]"""
import argparse, threading, time, webbrowser
from . import config, scheduler
from .server import app


def main():
    ap = argparse.ArgumentParser(description=f"{config.APP_NAME} assistant")
    ap.add_argument("--port", type=int, default=config.get("port"))
    ap.add_argument("--no-browser", action="store_true")
    a = ap.parse_args()
    host = "0.0.0.0" if config.get("allow_lan") else "127.0.0.1"
    scheduler.start()
    url = f"http://127.0.0.1:{a.port}"
    print(f"\n  {config.APP_NAME} is running at {url}\n  (Ctrl+C to stop)\n")
    if not a.no_browser:
        threading.Thread(target=lambda: (time.sleep(1.2), webbrowser.open(url)), daemon=True).start()
    app.run(host=host, port=a.port, threaded=True, debug=False, use_reloader=False)


if __name__ == "__main__":
    main()
