"use strict";
/* Animated black hole behind the UI: tilted accretion disk with Doppler glow, gravitationally lensed
   arcs over and under the shadow, a photon ring, and stars spiralling in. Pure canvas, no libraries.
   Modes (Settings → General → Background): full | reduced | off */
(() => {
  const cv = document.createElement("canvas");
  cv.id = "bh";
  document.body.prepend(cv);
  const ctx = cv.getContext("2d");
  let W = 0, H = 0, mode = "full", last = 0, t = 0, raf = 0;
  const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const saved = localStorage.getItem("fx");
  mode = saved || (reduced ? "off" : "full");

  const RIN = 1.55, ROUT = 5.4;
  let disk = [], stars = [], dust = [];
  const heatColor = h => `hsl(${Math.round(272 + 130 * h) % 360},${Math.round(78 + 22 * h)}%,${Math.round(40 + 42 * h)}%)`;
  const BUCKETS = 14, COLS = Array.from({ length: BUCKETS }, (_, i) => heatColor(i / (BUCKETS - 1)));

  function build() {
    const n = mode === "reduced" ? 520 : 2000;
    disk = Array.from({ length: n }, () => {
      const rn = RIN + Math.pow(Math.random(), 1.8) * (ROUT - RIN), heat = 1 - (rn - RIN) / (ROUT - RIN);
      return { rn, a: Math.random() * 6.2832, sp: 1.05 / Math.pow(rn, 1.5), s: 0.7 + Math.random() * 1.1,
               jy: (Math.random() - 0.5) * 0.06, b: Math.round(heat * (BUCKETS - 1)), heat };
    }).sort((a, b) => a.b - b.b);          // sorted so the colour is set once per bucket, not per particle
    stars = Array.from({ length: mode === "reduced" ? 70 : 230 }, () => newStar(true));
    dust = Array.from({ length: 140 }, () => ({ x: Math.random(), y: Math.random(), p: Math.random() * 6.28, s: Math.random() * 1.1 + 0.3 }));
  }
  function newStar(anywhere) {
    return { d: (anywhere ? 0.25 + Math.random() * 0.75 : 1) * Math.max(W, H) * 0.75, a: Math.random() * 6.2832,
             v: 0.6 + Math.random() * 0.8, s: 0.7 + Math.random() * 1.2 };
  }
  function resize() { W = cv.width = innerWidth; H = cv.height = innerHeight; }

  function frame(now) {
    raf = requestAnimationFrame(frame);
    const fps = mode === "reduced" ? 20 : 32;
    if (now - last < 1000 / fps) return;
    const dt = Math.min(64, now - last) / 16.7; last = now; t += dt;

    // the whole hole drifts slowly across the screen
    const R = Math.min(W, H) * 0.115;
    const cx = W * 0.70 + Math.sin(t * 0.0042) * W * 0.07, cy = H * 0.52 + Math.cos(t * 0.0031) * H * 0.05;
    const tilt = 0.2 + Math.sin(t * 0.0023) * 0.035;

    ctx.globalCompositeOperation = "source-over";
    ctx.fillStyle = "rgba(0,0,0,0.24)";
    ctx.fillRect(0, 0, W, H);
    ctx.globalCompositeOperation = "lighter";

    // faint twinkling background stars
    for (const d of dust) {
      ctx.globalAlpha = 0.25 + 0.2 * Math.sin(t * 0.05 + d.p);
      ctx.fillStyle = "#cfd8ff";
      ctx.fillRect(d.x * W, d.y * H, d.s, d.s);
    }
    // stars falling in, spiralling faster as they get close
    const rmax = Math.max(W, H) * 0.75;
    for (const s of stars) {
      s.a += 0.0016 * dt * Math.pow(rmax / s.d, 0.9) * s.v;
      s.d -= (0.25 + 160 / s.d) * dt * s.v * 0.9;
      if (s.d < R * 1.1) { Object.assign(s, newStar(false)); continue; }
      ctx.globalAlpha = Math.min(0.85, 0.15 + (R * 4) / s.d * 0.6);
      ctx.fillStyle = "#bcd0ff";
      ctx.fillRect(cx + Math.cos(s.a) * s.d, cy + Math.sin(s.a) * s.d * 0.78, s.s, s.s);
    }

    const front = [];
    const Rl = R * 1.13;
    let cb = -1;
    for (const p of disk) {
      p.a += p.sp * 0.045 * dt;
      const c = Math.cos(p.a), sn = Math.sin(p.a);
      const beam = 0.5 + 0.5 * (0.55 - 0.45 * c);                 // side moving toward us is brighter
      const alpha = Math.min(0.9, (0.18 + p.heat * 0.55) * beam * 1.25);
      if (sn >= 0) { front.push(p); continue; }                   // near half is drawn after the shadow
      const x = cx + p.rn * R * c, y = cy + (p.rn * R * sn + p.jy * R) * tilt;
      if (p.b !== cb) { ctx.fillStyle = COLS[p.b]; cb = p.b; }
      ctx.globalAlpha = alpha; ctx.fillRect(x, y, p.s, p.s);
      // lensed image of the far side bent over the top, and a fainter one under the bottom
      const lr = Rl * (1 + (p.rn - RIN) * 0.07);
      ctx.globalAlpha = alpha * 0.7;
      ctx.fillRect(cx + lr * c, cy + lr * sn, p.s, p.s);
      ctx.globalAlpha = alpha * 0.32;
      ctx.fillRect(cx + lr * 0.96 * c, cy - lr * 0.96 * sn, p.s, p.s);
    }

    // photon ring glow, then the shadow itself
    ctx.globalCompositeOperation = "lighter";
    const g = ctx.createRadialGradient(cx, cy, R * 0.97, cx, cy, R * 1.55);
    g.addColorStop(0, "rgba(255,226,170,0.55)"); g.addColorStop(0.18, "rgba(255,150,70,0.20)");
    g.addColorStop(0.55, "rgba(120,80,255,0.06)"); g.addColorStop(1, "rgba(0,0,0,0)");
    ctx.globalAlpha = 1; ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(cx, cy, R * 1.55, 0, 6.2832); ctx.fill();
    ctx.globalCompositeOperation = "source-over";
    ctx.fillStyle = "#000";
    ctx.beginPath(); ctx.arc(cx, cy, R, 0, 6.2832); ctx.fill();
    ctx.strokeStyle = "rgba(255,238,205,0.85)"; ctx.lineWidth = 1.4;
    ctx.beginPath(); ctx.arc(cx, cy, R * 1.012, 0, 6.2832); ctx.stroke();

    // near half of the disk crosses in front of the shadow
    ctx.globalCompositeOperation = "lighter";
    cb = -1;
    for (const p of front) {
      const c = Math.cos(p.a), sn = Math.sin(p.a);
      const beam = 0.5 + 0.5 * (0.55 - 0.45 * c);
      ctx.globalAlpha = Math.min(0.95, (0.22 + p.heat * 0.6) * beam * 1.3);
      if (p.b !== cb) { ctx.fillStyle = COLS[p.b]; cb = p.b; }
      ctx.fillRect(cx + p.rn * R * c, cy + (p.rn * R * sn + p.jy * R) * tilt, p.s, p.s);
    }
    ctx.globalAlpha = 1;
  }

  function apply(m) {
    mode = m; localStorage.setItem("fx", m);
    cancelAnimationFrame(raf);
    cv.style.display = m === "off" ? "none" : "block";
    if (m === "off") return;
    resize(); build(); ctx.fillStyle = "#000"; ctx.fillRect(0, 0, W, H);
    last = 0; raf = requestAnimationFrame(frame);
  }
  window.setFx = apply;
  window.getFx = () => mode;
  addEventListener("resize", () => { if (mode !== "off") { resize(); build(); } });
  apply(mode);
})();
